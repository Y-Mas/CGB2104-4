package cn.tedu.storage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StorageApplicationTests {

    @Test
    void contextLoads() {
    }

}
