package cn.tedu.order.service;

import cn.tedu.order.entity.Order;

public interface OrderService {
    void create(Order order);
}
